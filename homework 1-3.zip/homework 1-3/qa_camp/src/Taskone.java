public class Taskone {

    public static void main (String [] args){
        System.out.println("Oksana Onufreiv");
    }
}
