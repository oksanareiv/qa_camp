public class Tasktwo {
    public static void main (String [] args){
        String name = "Oksana";
        for(int i = 0; i < name.length(); i++){
            System.out.println(name.charAt(i));
        }
    }
}
