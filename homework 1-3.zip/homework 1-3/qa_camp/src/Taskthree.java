public class Taskthree {
    public static void main(String [] args){
        int n=25;
        if(n!=10){
            System.out.println(n);
        }else{
            System.out.println("Variable is 10");
        }
    }
}
