public class Taskfour {
    public static void main(String [] args){
        String name = "Oksana";
        int i=0;
        while(i<name.length()){
            System.out.println(name.charAt(i));
            i++;
        }
    }
}
